﻿using System;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;
using System.Security;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("SimpleInjector.DynamicAssemblyCompilation")]
[assembly: AssemblyDescription("Enabled Dynamic Assembly Compilation for optimized performance.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Simple Injector")]
[assembly: AssemblyProduct("SimpleInjector.DynamicAssemblyCompilation")]
[assembly: AssemblyCopyright("Copyright © Simple Injector Contributors")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("e385281d-9c56-4399-9d6d-83ab1277238b")]

[assembly: NeutralResourcesLanguage("en-US")]