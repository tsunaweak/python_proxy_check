﻿// Copyright (c) Simple Injector Contributors. All rights reserved.
// Licensed under the MIT License. See LICENSE file in the project root for license information.

namespace SimpleInjector.Decorators
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Diagnostics.CodeAnalysis;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Reflection;

    internal static class DecoratorHelpers
    {
        private static readonly MethodInfo EnumerableSelectMethod =
            Helpers.GetGenericMethodDefinition(() => Enumerable.Select(null, (Func<int, int>?)null));

        private static readonly MethodInfo DecoratorHelpersReadOnlyCollectionMethod =
            Helpers.GetGenericMethodDefinition(() => ReadOnlyCollection<int>(null!));

        // This method name does not describe what it does, but since the C# compiler will create an iterator
        // type named after this method, it allows us to return a type that has a nice name that will show up
        // during debugging.
        public static IEnumerable<T> ReadOnlyCollection<T>(T[] collection)
        {
            for (int index = 0; index < collection.Length; index++)
            {
                yield return collection[index];
            }
        }

        internal static IEnumerable MakeReadOnly(Type elementType, Array collection)
        {
            var readOnlyCollection =
                DecoratorHelpersReadOnlyCollectionMethod
                    .MakeGenericMethod(elementType)
                    .Invoke(null, new object[] { collection });

            return (IEnumerable)readOnlyCollection;
        }

        [SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily",
            Justification = "I don't care about the extra casts. This is not a performance critical part.")]
        internal static Type DetermineImplementationType(Expression expression,
            InstanceProducer registeredProducer)
        {
            // A ConstantExpression with null is supplied in case of a uncontrolled collection.
            if (expression is ConstantExpression constant && constant.Value is null)
            {
                return constant.Type;
            }

            return registeredProducer.Registration.ImplementationType;
        }

        internal static void AddRange<T>(this Collection<T> collection, IEnumerable<T> range)
        {
            foreach (var item in range)
            {
                collection.Add(item);
            }
        }

        internal static IEnumerable Select(this IEnumerable source, Type type, Delegate selector)
        {
            var selectMethod = EnumerableSelectMethod.MakeGenericMethod(type, type);

            return (IEnumerable)selectMethod.Invoke(null, new object[] { source, selector });
        }

        internal static MethodCallExpression Select(
            Expression collectionExpression, Type type, Delegate selector)
        {
            // We make use of .NET's built in Enumerable.Select to wrap the collection with the decorators.
            var selectMethod = EnumerableSelectMethod.MakeGenericMethod(type, type);

            return Expression.Call(selectMethod, collectionExpression, Expression.Constant(selector));
        }

        internal static bool DecoratesServiceType(Type serviceType, ConstructorInfo decoratorConstructor)
        {
            int numberOfServiceTypeDependencies =
                GetNumberOfServiceTypeDependencies(serviceType, decoratorConstructor);

            return numberOfServiceTypeDependencies == 1;
        }

        // Returns the base type of the decorator that can be used for decoration (because serviceType might
        // be open generic, while the base type might not be).
        internal static Type GetDecoratingBaseType(Type serviceType, ConstructorInfo decoratorConstructor)
        {
            var abstractions = Types.GetBaseTypeCandidates(serviceType, decoratorConstructor.DeclaringType);

            var decoratorInterfaces =
                from abstraction in abstractions
                where decoratorConstructor.GetParameters()
                    .Any(parameter => IsDecorateeParameter(parameter, abstraction))
                select abstraction;

            return decoratorInterfaces.FirstOrDefault();
        }

        internal static int GetNumberOfServiceTypeDependencies(
            Type serviceType, ConstructorInfo decoratorConstructor)
        {
            Type decoratorType = GetDecoratingBaseType(serviceType, decoratorConstructor);

            if (decoratorType is null)
            {
                return 0;
            }

            var validServiceTypeArguments =
                from parameter in decoratorConstructor.GetParameters()
                where IsDecorateeParameter(parameter, decoratorType)
                select parameter;

            return validServiceTypeArguments.Count();
        }

        internal static bool DecoratesBaseTypes(Type serviceType, ConstructorInfo decoratorConstructor)
        {
            var baseTypes = GetValidDecoratorConstructorArgumentTypes(serviceType, decoratorConstructor);

            var constructorParameters = decoratorConstructor.GetParameters();

            // For a type to be a decorator, one of its constructor parameter types must exactly match with
            // one of the interfaces it implements or base types it inherits from.
            var decoratorParameters =
                from baseType in baseTypes
                from parameter in constructorParameters
                where parameter.ParameterType == baseType
                    || (typeof(Func<>).IsGenericTypeDefinitionOf(parameter.ParameterType)
                        && parameter.ParameterType == typeof(Func<>).MakeGenericType(baseType))
                select parameter;

            return decoratorParameters.Any();
        }

        internal static Type[] GetValidDecoratorConstructorArgumentTypes(
            Type serviceType, ConstructorInfo decoratorConstructor)
        {
            Type decoratingBaseType = GetDecoratingBaseType(serviceType, decoratorConstructor);

            return (
                from baseType in decoratorConstructor.DeclaringType.GetBaseTypesAndInterfaces()
                where IsDecorateeDependencyType(baseType, decoratingBaseType)
                select baseType)
                .ToArray();
        }

        internal static bool IsDecorateeParameter(ParameterInfo parameter, Type decoratingType) =>
            IsDecorateeDependencyType(parameter.ParameterType, decoratingType)
            || IsDecorateeFactoryDependencyType(parameter.ParameterType, decoratingType);

        internal static bool IsDecorateeDependencyType(Type dependencyType, Type serviceType) =>
            dependencyType == serviceType;

        internal static bool IsDecorateeFactoryDependencyType(Type dependencyType, Type decoratingType) =>
            IsScopelessDecorateeFactoryDependencyType(dependencyType, decoratingType)
            || IsScopeDecorateeFactoryDependencyParameter(dependencyType, decoratingType);

        internal static bool IsScopelessDecorateeFactoryDependencyType(
            Type dependencyType, Type decoratingType) =>
            typeof(Func<>).IsGenericTypeDefinitionOf(dependencyType)
                && dependencyType == typeof(Func<>).MakeGenericType(decoratingType);

        internal static bool IsScopeDecorateeFactoryDependencyParameter(
            Type parameterType, Type decoratingType) =>
            typeof(Func<,>).IsGenericTypeDefinitionOf(parameterType)
                && parameterType == typeof(Func<,>).MakeGenericType(typeof(Scope), decoratingType);
    }
}