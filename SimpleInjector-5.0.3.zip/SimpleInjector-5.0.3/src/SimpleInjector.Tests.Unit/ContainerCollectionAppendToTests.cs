﻿namespace SimpleInjector.Tests.Unit
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class ContainerCollectionAppendToTests
    {
        [TestMethod]
        public void AppendTo_WithValidArguments_Suceeds()
        {
            // Arrange
            var container = ContainerFactory.New();

            // Act
            container.Collection.Append(typeof(object), CreateRegistration(container));
        }

        [TestMethod]
        public void AppendTo_WithNullServiceTypeArgument_ThrowsException()
        {
            // Arrange
            var container = ContainerFactory.New();

            Type invalidServiceType = null;

            // Act
            Action action =
                () => container.Collection.Append(invalidServiceType, CreateRegistration(container));

            // Assert
            AssertThat.ThrowsWithParamName<ArgumentNullException>("serviceType", action);
        }

        [TestMethod]
        public void AppendTo_WithNullRegistrationArgument_ThrowsException()
        {
            // Arrange
            var container = ContainerFactory.New();

            Registration invalidRegistration = null;

            // Act
            Action action = () => container.Collection.Append(typeof(object), invalidRegistration);

            // Assert
            AssertThat.ThrowsWithParamName<ArgumentNullException>("registration", action);
        }

        [TestMethod]
        public void AppendTo_WithRegistrationForDifferentContainer_ThrowsException()
        {
            // Arrange
            var container = ContainerFactory.New();

            var differentContainer = new Container();

            Registration invalidRegistration = CreateRegistration(differentContainer);

            // Act
            Action action = () => container.Collection.Append(typeof(object), invalidRegistration);

            // Assert
            AssertThat.ThrowsWithParamName<ArgumentException>("registration", action);
            AssertThat.ThrowsWithExceptionMessageContains<ArgumentException>(
                "The supplied Registration belongs to a different Container", action);
        }

        [TestMethod]
        public void AppendTo_ForUnregisteredCollection_ResolvesThatRegistrationWhenRequested()
        {
            // Arrange
            var container = ContainerFactory.New();

            var registration = Lifestyle.Transient.CreateRegistration<PluginImpl>(container);

            container.Collection.Append(typeof(IPlugin), registration);

            // Act
            var instance = container.GetAllInstances<IPlugin>().Single();

            // Assert
            AssertThat.IsInstanceOfType(typeof(PluginImpl), instance);
        }

        [TestMethod]
        public void AppendTo_CalledTwice_ResolvesBothRegistrationsWhenRequested()
        {
            // Arrange
            var container = ContainerFactory.New();

            var registration1 = Lifestyle.Transient.CreateRegistration<PluginImpl>(container);
            var registration2 = Lifestyle.Transient.CreateRegistration<PluginImpl2>(container);

            container.Collection.Append(typeof(IPlugin), registration1);
            container.Collection.Append(typeof(IPlugin), registration2);

            // Act
            var instances = container.GetAllInstances<IPlugin>().ToArray();

            // Assert
            AssertThat.IsInstanceOfType(typeof(PluginImpl), instances[0]);
            AssertThat.IsInstanceOfType(typeof(PluginImpl2), instances[1]);
        }

        [TestMethod]
        public void AppendTo_CalledAfterRegisterCollectionWithTypes_CombinedAllRegistrationsWhenRequested()
        {
            // Arrange
            var container = ContainerFactory.New();

            container.Collection.Register<IPlugin>(new[] { typeof(PluginImpl) });

            var registration = Lifestyle.Transient.CreateRegistration<PluginImpl2>(container);

            container.Collection.Append(typeof(IPlugin), registration);

            // Act
            var instances = container.GetAllInstances<IPlugin>().ToArray();

            // Assert
            AssertThat.IsInstanceOfType(typeof(PluginImpl), instances[0]);
            AssertThat.IsInstanceOfType(typeof(PluginImpl2), instances[1]);
        }

        [TestMethod]
        public void AppendTo_CalledAfterRegisterCollectionWithRegistration_CombinedAllRegistrationsWhenRequested()
        {
            // Arrange
            var container = ContainerFactory.New();

            var registration1 = Lifestyle.Transient.CreateRegistration<PluginImpl>(container);
            var registration2 = Lifestyle.Transient.CreateRegistration<PluginImpl2>(container);

            container.Collection.Register(typeof(IPlugin), new[] { registration1 });

            container.Collection.Append(typeof(IPlugin), registration2);

            // Act
            var instances = container.GetAllInstances<IPlugin>().ToArray();

            // Assert
            AssertThat.IsInstanceOfType(typeof(PluginImpl), instances[0]);
            AssertThat.IsInstanceOfType(typeof(PluginImpl2), instances[1]);
        }

        [TestMethod]
        public void AppendTo_CalledAfterTheFirstItemIsRequested_ThrowsExpectedException()
        {
            // Arrange
            var container = ContainerFactory.New();

            var registration1 = Lifestyle.Transient.CreateRegistration<PluginImpl>(container);
            var registration2 = Lifestyle.Transient.CreateRegistration<PluginImpl2>(container);

            container.Collection.Append(typeof(IPlugin), registration1);

            var instances = container.GetAllInstances<IPlugin>().ToArray();

            // Act
            Action action = () => container.Collection.Append(typeof(IPlugin), registration2);

            // Assert
            AssertThat.Throws<InvalidOperationException>(action);
        }

        [TestMethod]
        public void AppendTo_OnContainerUncontrolledCollection_ThrowsExpressiveException()
        {
            // Arrange
            var container = ContainerFactory.New();

            IEnumerable<IPlugin> containerUncontrolledCollection = new[] { new PluginImpl() };

            container.Collection.Register<IPlugin>(containerUncontrolledCollection);

            var registration = Lifestyle.Transient.CreateRegistration<PluginImpl>(container);

            // Act
            Action action = () => container.Collection.Append(typeof(IPlugin), registration);

            // Assert
            AssertThat.ThrowsWithExceptionMessageContains<NotSupportedException>(@"
                appending registrations to these collections is not supported. Please register the collection
                with one of the other Container.Collection.Register overloads if appending is required."
                .TrimInside(),
                action);
        }

        [TestMethod]
        public void GetAllInstances_RegistrationAppendedToExistingOpenGenericRegistration_ResolvesTheExtectedCollection()
        {
            // Arrange
            Type[] expectedHandlerTypes = new[]
            {
                typeof(NewConstraintEventHandler<StructEvent>),
                typeof(StructEventHandler),
            };

            var container = ContainerFactory.New();

            container.Collection.Register(typeof(IEventHandler<>), new[] { typeof(NewConstraintEventHandler<>) });

            var registration = Lifestyle.Transient.CreateRegistration<StructEventHandler>(container);

            container.Collection.Append(typeof(IEventHandler<>), registration);

            // Act
            Type[] actualHandlerTypes = container.GetAllInstances(typeof(IEventHandler<StructEvent>))
                .Select(h => h.GetType()).ToArray();

            // Assert
            AssertThat.SequenceEquals(expectedHandlerTypes, actualHandlerTypes);
        }

        [TestMethod]
        public void GetAllInstances_RegistrationPrependedToExistingOpenGenericRegistration_ResolvesTheExtectedCollection()
        {
            // Arrange
            Type[] expectedHandlerTypes = new[]
            {
                typeof(StructEventHandler),
                typeof(NewConstraintEventHandler<StructEvent>),
            };

            var container = ContainerFactory.New();

            var registration = Lifestyle.Transient.CreateRegistration<StructEventHandler>(container);

            container.Collection.Append(typeof(IEventHandler<>), registration);

            container.Collection.Register(typeof(IEventHandler<>), new[] { typeof(NewConstraintEventHandler<>) });

            // Act
            Type[] actualHandlerTypes = container.GetAllInstances(typeof(IEventHandler<StructEvent>))
                .Select(h => h.GetType()).ToArray();

            // Assert
            AssertThat.SequenceEquals(expectedHandlerTypes, actualHandlerTypes);
        }

        [TestMethod]
        public void GetAllInstances_MultipleAppendedOpenGenericTypes_ResolvesTheExpectedCollection()
        {
            // Arrange
            Type[] expectedHandlerTypes = new[]
            {
                typeof(NewConstraintEventHandler<StructEvent>),
                typeof(StructConstraintEventHandler<StructEvent>),
                typeof(AuditableEventEventHandler<StructEvent>)
            };

            var container = ContainerFactory.New();

            container.Collection.Append(typeof(IEventHandler<>), typeof(NewConstraintEventHandler<>));
            container.Collection.Append(typeof(IEventHandler<>), typeof(StructConstraintEventHandler<>));
            container.Collection.Append(typeof(IEventHandler<>), typeof(AuditableEventEventHandler<>));

            // Act
            Type[] actualHandlerTypes = container.GetAllInstances(typeof(IEventHandler<StructEvent>))
                .Select(h => h.GetType()).ToArray();

            // Assert
            AssertThat.SequenceEquals(expectedHandlerTypes, actualHandlerTypes);
        }

        [TestMethod]
        public void GetAllInstances_MultipleAppendedOpenGenericTypesMixedWithClosedGenericRegisterCollection_ResolvesTheExpectedCollection()
        {
            // Arrange
            Type[] expectedHandlerTypes = new[]
            {
                typeof(NewConstraintEventHandler<StructEvent>),
                typeof(AuditableEventEventHandler<StructEvent>),
                typeof(StructConstraintEventHandler<StructEvent>),
            };

            var container = ContainerFactory.New();

            container.Collection.Append(typeof(IEventHandler<>), typeof(NewConstraintEventHandler<>));

            container.Collection.Register(typeof(IEventHandler<StructEvent>), new[]
            {
                typeof(AuditableEventEventHandler<StructEvent>)
            });

            container.Collection.Append(typeof(IEventHandler<>), typeof(StructConstraintEventHandler<>));

            // Act
            Type[] actualHandlerTypes = container.GetAllInstances(typeof(IEventHandler<StructEvent>))
                .Select(h => h.GetType()).ToArray();

            // Assert
            AssertThat.SequenceEquals(expectedHandlerTypes, actualHandlerTypes);
        }

        [TestMethod]
        public void GetAllInstances_MultipleOpenGenericTypesAppendedToPreRegistrationWithOpenGenericType_ResolvesTheExpectedCollection()
        {
            // Arrange
            Type[] expectedHandlerTypes = new[]
            {
                typeof(NewConstraintEventHandler<StructEvent>),
                typeof(StructConstraintEventHandler<StructEvent>),
                typeof(AuditableEventEventHandler<StructEvent>)
            };

            var container = ContainerFactory.New();

            container.Collection.Register(typeof(IEventHandler<>), new[] { typeof(NewConstraintEventHandler<>) });

            container.Collection.Append(typeof(IEventHandler<>), typeof(StructConstraintEventHandler<>));
            container.Collection.Append(typeof(IEventHandler<>), typeof(AuditableEventEventHandler<>));

            // Act
            Type[] actualHandlerTypes = container.GetAllInstances(typeof(IEventHandler<StructEvent>))
                .Select(h => h.GetType()).ToArray();

            // Assert
            AssertThat.SequenceEquals(expectedHandlerTypes, actualHandlerTypes);
        }

        [TestMethod]
        public void GetAllInstances_AppendingInstancesOfOpenGenericImplementations_ResolvesTheExpectedCollection()
        {
            // Arrange
            Type[] expectedHandlerTypes = new[]
            {
                typeof(NewConstraintEventHandler<StructEvent>),
                typeof(StructConstraintEventHandler<StructEvent>),
            };

            var container = ContainerFactory.New();

            container.Collection.Register(typeof(IEventHandler<>), new[] { typeof(NewConstraintEventHandler<>) });

            container.Collection
                .AppendInstance(typeof(IEventHandler<>), new StructConstraintEventHandler<StructEvent>());

            // AuditableEventEventHandler<AuditableEvent> can be registered, and resolved, but should not
            // be resolved as part of IEnumerable<IEventHandler<StructEvent>>.
            container.Collection
                .AppendInstance(typeof(IEventHandler<>), new AuditableEventEventHandler<AuditableEvent>());

            // Act
            var handlers = container.GetAllInstances(typeof(IEventHandler<StructEvent>));
            Type[] actualHandlerTypes = handlers.Select(h => h.GetType()).ToArray();

            // Assert
            AssertThat.SequenceEquals(expectedHandlerTypes, actualHandlerTypes);
        }
        
        [TestMethod]
        public void GetAllInstances_AppendingInstancesOfClosedGenericImplementation_ResolvesTheExpectedCollection()
        {
            // Arrange
            Type[] expectedHandlerTypes = new[]
            {
                typeof(NewConstraintEventHandler<StructEvent>),
                typeof(AuditableEventEventHandler<StructEvent>),
            };

            var container = ContainerFactory.New();

            container.Collection.Register(typeof(IEventHandler<>), new[] { typeof(NewConstraintEventHandler<>) });

            container.Collection
                .AppendInstance<IEventHandler<StructEvent>>(new AuditableEventEventHandler<StructEvent>());

            // Act
            var handlers = container.GetAllInstances(typeof(IEventHandler<StructEvent>));
            Type[] actualHandlerTypes = handlers.Select(h => h.GetType()).ToArray();

            // Assert
            AssertThat.SequenceEquals(expectedHandlerTypes, actualHandlerTypes);
        }

        [TestMethod]
        public void GetAllInstances_RegistrationAppendedToExistingRegistrationForSameClosedType_ResolvesTheInstanceWithExpectedLifestyle()
        {
            // Arrange
            var container = ContainerFactory.New();

            container.Collection.Register(typeof(IEventHandler<>), new[]
            {
                // Here we make a closed registration; this causes an explicit registration for the
                // IEventHandlerStructEvent> collection.
                typeof(NewConstraintEventHandler<StructEvent>),
            });

            var registration = Lifestyle.Singleton
                .CreateRegistration(typeof(StructConstraintEventHandler<StructEvent>), container);

            container.Collection.Append(typeof(IEventHandler<>), registration);

            // Act
            var handler1 = container.GetAllInstances<IEventHandler<StructEvent>>().Last();
            var handler2 = container.GetAllInstances<IEventHandler<StructEvent>>().Last();

            // Assert
            AssertThat.IsInstanceOfType(typeof(StructConstraintEventHandler<StructEvent>), handler1);
            Assert.AreSame(handler1, handler2, "The instance was expected to be registered as singleton");
        }

        [TestMethod]
        public void GetAllInstances_DelegatedRegistrationAppendedToExistingRegistrationForSameClosedType_ResolvesTheInstanceWithExpectedLifestyle()
        {
            // Arrange
            var container = ContainerFactory.New();

            container.Collection.Register(typeof(IEventHandler<>), new[]
            {
                typeof(NewConstraintEventHandler<StructEvent>),
            });

            var registration = Lifestyle.Singleton.CreateRegistration(
                typeof(IEventHandler<StructEvent>),
                () => new StructConstraintEventHandler<StructEvent>(),
                container);

            container.Collection.Append(typeof(IEventHandler<>), registration);

            // Act
            var handler1 = container.GetAllInstances<IEventHandler<StructEvent>>().Last();
            var handler2 = container.GetAllInstances<IEventHandler<StructEvent>>().Last();

            // Assert
            AssertThat.IsInstanceOfType(typeof(StructConstraintEventHandler<StructEvent>), handler1);
            Assert.AreSame(handler1, handler2, "The instance was expected to be registered as singleton");
        }

        private static Registration CreateRegistration(Container container) =>
            Lifestyle.Transient.CreateRegistration<PluginImpl>(container);
    }
}