﻿namespace SimpleInjector.Tests.Unit.Duplicates
{
    public interface IDuplicate
    {
    }

    public interface IDuplicate<T>
    {
    }
}