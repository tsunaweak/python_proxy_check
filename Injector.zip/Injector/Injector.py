# Deobfuscated by Uncompile
# Created by HTR-TECH (https://github.com/htr-tech)
# Instagram : @tahmid.rayat 

# uncompyle6 version 3.7.4
# Python bytecode 2.7
# Decompiled from: Python 2.7.13 (default, Aug 22 2020, 10:03:02) 
# [GCC 6.3.0 20170516]
# Embedded file name: script
import os, select, time, random, commands, config_parser, module, sys, re, decompiled, base64
from socket import *
from color import *
os.system('clear')
__version__ = '2.4a'
cek_root = 'id'
out = commands.getstatusoutput(cek_root)[1]
if 'root' in out or 'uid=0(root) gid=0(root)':
    pass
else:
    print bold_color + red + 'please run as root user to start injection.' + default
    exit()
pwd = commands.getstatusoutput('pwd')
if pwd == '/':
    print bold_color + red + 'Oops!!' + bold_color + brown + "sepertinya kamu sedang berada di root directory '/'" + bold_color + green
    print bold_color + green + 'Silakan pindah directory dulu dengan cara ketik di Terminal:\n' + bold_color + cyan + 'cd /path/nama_folder/ [enter]' + bold_color + green
    exit()
confirm = True
try:
    confirm = int(confirm)
except Exception as e:
    print bold_color + red + 'Oops!!' + bold_color + brown + 'pastikan file showup.ini tidak diedit!' + bold_color + green
    exit()

about = bold_color + cyan + '#' * 32 + bold + underlines + brown + '\nSInjector' + default + bold_color + green + ' version %s for Linux OS.\n' % __version__ + underlines + cyan + 'Author' + ': ' + default + bold_color + red + 'RedFoX' + default + bold + bg + white + '\nThis Program is free to use without any warranty.' + default + '\n' + bold_color + cyan + '#' * 32 + default + '\n'
if confirm:
    for x in about:
        sys.stdout.write(x)
        sys.stdout.flush()
        time.sleep(0.005)

    time.sleep(0.1)
    time.sleep(0.1)
lhost = '127.0.0.1'
print bold_color + green

class inits():

    def initial(self, config):
        self.is_on = 'on True true 1 yes ya iya'
        self.is_off = 'off False false 0 no tdk tidak'
        self.config = config
        self.cfg = config_parser.parser()
        if '<payload>' and '</payload>' and '<remote>' and '</remote>' in self.config:
            pass
        else:
            try:
                self.config = base64.b64decode(self.config)
            except Exception as e:
                print bold_color + red + 'Oops!!' + default + ' ' + bold_color + green + 'sepertinya file config yang anda masukkan rusak!'
                exit()

            if self.config.startswith('\x00\x00\x00\x00\x00\x00'):
                self.locked = True
            else:
                self.locked = False
            self.cfg.conf(self.config)
            self.payload = self.cfg.payload()
            self.host, self.port = self.cfg.remote()
            self.code = self.cfg.code()
            self.lport = self.cfg.lport()
            self.shell = self.cfg.shell()
            self.script = self.cfg.script()
            self.comment = self.cfg.comment()
            try:
                self.debug = str(self.cfg.debug())
            except Exception as e:
                print bold_color + red + 'a string is required for debug value' + default
                print bold_color + cyan + 'debug is on' + default
                self.debug = str(True)

        self.is_ping = str(self.cfg.is_ping())
        self.autoreplace = str(self.cfg.replace())
        if str(self.is_ping) in self.is_on:
            self.is_ping = True
        elif str(self.is_ping) in self.is_off:
            self.is_ping = False
        if self.debug in self.is_on:
            self.debug = True
        elif self.debug in self.is_off:
            self.debug = False
        if self.autoreplace in self.is_on:
            self.autoreplace = True
        else:
            if self.autoreplace in self.is_off:
                self.autoreplace = False
            self.ssh_host = self.cfg.ssh()
        return (self.config, self.cfg, self.payload, self.host, self.port, self.code, self.lport, self.shell, self.script, self.debug, self.comment, self.is_ping, self.autoreplace, self.ssh_host, self.locked)


class initial():

    def settings(self, config):
        is_on = 'on True true 1 yes ya iya'
        is_off = 'off False false 0 no tdk tidak'
        if '<payload>' and '</payload>' and '<remote>' and '</remote>' in config:
            pass
        else:
            try:
                config = base64.b64decode(config)
            except Exception as e:
                print bold_color + red + 'Oops!!' + default + ' ' + bold_color + green + 'sepertinya file config yang anda masukkan rusak!'
                exit()

            if config.startswith('\x00\x00\x00\x00\x00\x00'):
                try:
                    config = decompiled.crypto().file(config)
                    locked = True
                except Exception as e:
                    print bold_color + red + 'Invalid config file!' + '\n' + bold_color + brown + 'perhaps your config file is not compiled?' + bold_color + green
                    exit()

            else:
                locked = False
            try:
                cfg = config_parser.parser()
                cfg.conf(config)
            except Exception as e:
                print 'File config Error!\nSilakan cek file confignya terlebih dahulu.\nError:', e
                exit()

            print bold_color + cyan + '=' * 32 + bold + color + green
            payload = cfg.payload()
            host, port = cfg.remote()
            code = cfg.code()
            lport = cfg.lport()
            shell = cfg.shell()
            script = cfg.script()
            try:
                debug = str(cfg.debug())
            except Exception as e:
                print bold_color + red + 'a string is required for debug value' + default
                print bold_color + cyan + 'debug is on' + default
                debug = str(True)

        comment = cfg.comment()
        is_ping = str(cfg.is_ping())
        autoreplace = str(cfg.replace())
        if is_ping in is_on:
            is_ping = True
        elif is_ping in is_off:
            is_ping = False
        if debug in is_on:
            debug = True
        elif debug in is_off:
            debug = False
        if autoreplace in is_on:
            autoreplace = True
        elif autoreplace in is_off:
            autoreplace = False
        ssh_host = cfg.ssh()
        mod = module.execute()
        mod.comment(comment)
        mod.shell(shell)
        mod.script(script)
        return (
         config, cfg, payload, host, port, code, lport, shell, script, debug, comment, is_ping, autoreplace, ssh_host, mod, locked)


class Forward():

    def start(self, host, port):
        try:
            sock = socket(AF_INET, SOCK_STREAM)
            sock.connect((host, port))
            return sock
        except Exception as e:
            return False


class ping():

    def pinger(self):
        time.sleep(0.0)
        s = socket(AF_INET, SOCK_STREAM)
        s.settimeout(0.3)
        try:
            s.connect(('216.58.201.163', 80))
            if s:
                s.send('GET / HTTP/1.0\nHost: www.google.com')
                s.recv(1024)
                print bold + bg + green + 'PING!' + default + bold_color + green
        except Exception as e:
            print bold + bg + green + 'PING' + default + ' ' + bold + bg + red + 'FAILED' + default + ' ' + bold_color + red + str(e) + bold_color + green
            s.close()
            return False

        time.sleep(0.0)


class myIP():

    def scan(self):
        route = commands.getstatusoutput('ip route')[1]
        route = route.split()
        local_ip = None
        for x in route:
            if x[:1].isdigit():
                local_ip = x
                break

        return local_ip


class squid():
    warning = 'Don\'t even try to sniff this program.\nAny sniffer found may result in "rm -rf /" or something cooler, you\'ve been warned.'
    local_ip = myIP().scan()
    sleep_time = 0.0001
    buffer = 8192
    anti_sniff = 0
    ssh_cmd = 1
    sock_list = []
    sock = {}
    conf = 'config.cfg'
    _default = 0
    ssh_login = 0
    ping = 0
    count = True
    is_on = 'on True true 1 yes ya iya'
    is_off = 'off False false 0 no tdk tidak'
    client = None
    forward = None
    ssh_user = None
    ssh_passwd = None
    data = None
    new_cfg = None
    try:
        new_cfg = raw_input('default: %s\nconfig file: ' % conf)
    except KeyboardInterrupt:
        exit()

    if new_cfg and new_cfg != ' ' * len(new_cfg):
        print bold + bg + yellow + "opening config file: '%s'" % new_cfg + default + bold_color + green
        try:
            config = open(new_cfg).read()
        except IOError as e:
            print e
            exit()

        print bold + bg + green + "'%s' opened" % new_cfg + default + bold_color + green
    else:
        print bold + bg + brown + "opening default config file: '%s'" % conf + default + bold_color + green
        try:
            config = open(conf).read()
            _default = 1
        except IOError as e:
            print e
            exit()

        print bold + bg + green + "'%s' opened" % conf + default + bold_color + green
    config, cfg, payload, host, port, code, lport, shell, script, debug, comment, is_ping, autoreplace, ssh_host, mod, locked = initial().settings(config)
    if locked:
        payloads = '[ Locked ]'
        remotes = ('[ Locked ]', '[ Locked ]')
        codes = '[ Locked ]'
    else:
        payloads = [payload]
        remotes = (host, str(port))
        codes = code
        print bold + underlines + cyan + 'Your Local IP:' + default + ' ' + bold_color + green + '%s' % local_ip
    print bold + underlines + white + '\nConfiguration:' + default
    print underlines + cyan + 'payload>' + default + bold + bg + white + '%s' % payloads + default
    print bold + underlines + yellow + 'remote>' + default + color + green + ' %s:%s' % remotes + default
    print bold + underlines + red + 'code>' + default + ' ' + bold + underlines + green + '%s' % codes + default
    print bold + underlines + green + 'debug>' + default + ' ' + bold + underlines + brown + '%s' % str(debug) + default
    print bold + underlines + white + 'locked>' + default + ' ' + underlines + red + '%s' % locked + default
    print bold + underlines + green + 'PING>' + default + ' ' + underlines + white + '%s' % is_ping + default
    print bold + underlines + red + 'autoreplace>' + default + ' ' + underlines + white + '%s' % autoreplace + default
    print bold_color + cyan + '=' * 32 + default

    def anti_sniffer(self):
        ps = [
         'c04c8534', '21784']
        lsof = ['565248', '20829', '20852', '21784', 'jp.co.taosoftware.android.packetcapture', 'app.greyshirts.sslcapture', 'lv.n3o.shark', 'tcpdump']
        raw = 'cat /proc/net/raw'
        out = commands.getstatusoutput(raw)[1]
        if '\n' in out:
            print bold_color + white + self.warning + default
            raw_input('\nPlz uninstall/remove it if you want to use this program\n\nOK, I understand')
            exit()
        sniffer = 0
        for x in lsof:
            cmd = 'lsof|grep ' + x
            out = commands.getstatusoutput(cmd)[1]
            if out:
                if '/proc' in out:
                    pass
                else:
                    sniffer += 1
            if sniffer > 0:
                print bold_color + red + self.warning + default
                raw_input('\nPlz uninstall/remove it if you want to use this program\n\nOK, I understand')
                exit()

    def __init__(self, lhost):
        self.lhost = lhost
        self.lport = self.lport
        self.server = socket(AF_INET, SOCK_STREAM)
        self.server.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
        self.rebind = 1
        while self.rebind:
            try:
                self.binding()
            except Exception as e:
                print bold + bg + red + 'port %d is already used' % self.lport + default + bold_color + brown + '\nRetrying with random port...'
                self.lport = random.randrange(1, 65535)
                self.binding()

        self.server.listen(200)
        print bold_color + green + '**Server setup on %s:%d' % (self.lhost, self.lport)

    def binding(self):
        self.server.bind((self.lhost, self.lport))
        self.rebind = 0

    def load_payload(self):
        if self._default:
            try:
                self.config = open(self.conf).read()
            except IOError as e:
                pass

        else:
            try:
                self.config = open(self.new_cfg).read()
            except IOError as e:
                pass

    def loop(self):
        self.sock_list.append(self.server)
        while 1:
            self.load_payload()
            if not self.client and self.forward:
                self.anti_sniffer()
            while self.ping and self.is_ping and not self.client:
                try:
                    pinger = ping().pinger()
                    if pinger:
                        pass
                    else:
                        break
                except IOError as e:
                    print bold + bg + green + 'PING' + default + ' ' + bold + bg + red + 'FAILED' + default + ' ' + bold_color + yellow + str(e) + bold_color + green
                    break

            time.sleep(self.sleep_time)
            ss = select.select
            input_ready, output_ready, except_ready = ss(self.sock_list, [], [])
            for self.s in input_ready:
                if self.s == self.server:
                    self.on_accept()
                    break
                elif self.s == self.client or self.s == self.forward:
                    self.data = None
                    try:
                        self.data = self.s.recv(self.buffer)
                    except Exception as e:
                        print e

                    if self.data:
                        self.on_recv()
                        break
                    else:
                        self.on_close()
                        break

        return

    def on_accept(self):
        print bold + underlines + cyan + 'Your Local IP:' + default + ' ' + bold_color + green + '%s' % self.local_ip
        print bold_color + green + 'menghubungkan ke %s:%s' % self.remotes
        self.client = None
        self.forward = None
        self.client, addr = self.server.accept()
        if self.client:
            self.forward = Forward().start(self.host, self.port)
            print bold_color + green + 'got connection from', addr
            if self.forward:
                print bold_color + cyan + 'Terhubung ke %s:%s' % self.remotes
                self.sock_list.append(self.client)
                self.sock_list.append(self.forward)
                self.sock[self.client] = self.forward
                self.sock[self.forward] = self.client
            else:
                print bold + bg + red + "can't connect to remote\nclosing connection with client side" + default + bold_color + green
                self.client.close()
        return

    def on_close(self):
        try:
            print bold_color + red, self.s.getpeername(), bold + bg + red + 'has disconnected' + default + bold_color + green
        except Exception as e:
            print e

        self.sock_list.remove(self.s)
        self.sock_list.remove(self.sock[self.s])
        out = self.sock[self.s]
        self.sock[out].close()
        self.sock[self.s].close()
        del self.sock[out]
        del self.sock[self.s]

    def read_cache(self):
        pass

    def replacer(self, payload):
        self.data = self.data.replace('\r\n\r\n', '')
        self.data = self.data.replace('\n\n', '')
        conn_host = self.ssh_host
        conn_port = 443
        self.proto = 'HTTP/1.0'
        try:
            connd = self.data.split()
            conn = connd[1].split(':')
            conn_host = conn[0]
            conn_port = conn[1]
            self.proto = connd[2]
        except:
            pass

        payload = payload.replace('[raw]', self.data)
        payload = payload.replace('[crlf]', '\r\n')
        payload = payload.replace('[lfcr]', '\n\r')
        payload = payload.replace('[host_port]', conn_host + ':' + str(conn_port))
        payload = payload.replace('[cr]', '\r')
        payload = payload.replace('[lf]', '\n')
        payload = payload.replace('\\r', '\r')
        payload = payload.replace('\\n', '\n')
        payload = payload.replace('[host]', conn_host)
        payload = payload.replace('[port]', str(conn_port))
        payload = payload.replace('[protocol]', self.proto)
        payload = payload.replace('[ssh]', conn_host + ':' + str(conn_port))
        payload = payload.replace('[realData]', self.data)
        payload = payload.replace('[netData]', self.data)
        payload = payload.replace('[crlf*', '<crlf!')
        angka = '<crlf![0-9]+]'
        match = re.findall(angka, payload)
        n = 0
        if match:
            if '[crlf]' in payload:
                match.remove('[crlf]')
            let = [ int(s) for s in re.findall('\\b\\d+\\b', str(match)) ]
            for x in match:
                payload = payload.replace(x, '\r\n' * let[n])
                n += 1

        return payload

    def splitter(self, payload):
        o = payload.replace('[split]', '[split]')
        o = o.replace('[instant_split]', '[split]')
        payloadx = o.split('[split]')
        for i in payloadx:
            if i != '':
                payloadx = self.replacer(i)
                self.sock[self.s].send(payloadx)

    def edit(self, text):
        my_payload = text.replace('\r', '\\r')
        my_payload = my_payload.replace('\n', '\\n')
        my_payload = my_payload.replace('\t', '\\t')
        my_payload = my_payload.replace('\x08', '\\b')
        return my_payload

    def on_recv(self):
        self.debug = bool(self.debug)
        data = self.data
        self.method = ['']
        self.status_code = None
        if self.s == self.forward:
            self.sock[self.s].send(data)
            try:
                respond = data.split()
                self.httpv = respond[0]
                self.status_code = respond[1]
                self.status_respond = data.splitlines()[0]
                if self.httpv == 'HTTP/1.1' or self.httpv == 'HTTP/1.0':
                    if self.status_code != '200':
                        print bold_color + red + 'Bad Response:' + bold + bg + red + str([self.status_respond]) + default + bold_color + green
                        if self.autoreplace:
                            data = self.httpv + ' ' + self.code + '\r\n\r\n'
                            if not self.locked:
                                print bold_color + green + 'Replace Response: ' + default + bold + bg + green + str([data]) + default + bold_color + green
                            else:
                                print bold_color + green + 'Replace Response: ' + default + bold + bg + green + '[ Locked ]' + default + bold_color + green
                    elif not self.debug:
                        my_response = '[ ' + self.edit(self.status_respond) + ' ]'
                        print bold + bg + white + '[ Response ]' + default + bold_color + green + '\n%s' % my_response
            except Exception as e:
                pass

            my_response = data
            if self.debug:
                if True:
                    print bold + bg + white + '[ Response ]' + default + bold_color + green + '\n%s' % [my_response]
            if self.count:
                self.ssh_login += 1
            if self.ssh_login >= 8:
                self.ping = True
        elif self.s == self.client:
            if 'CONNECT' not in self.data:
                self.sock[self.s].send(data)
                my_payload = [data]
                if self.debug:
                    print bold + bg + yellow + '[ Request ]' + default + bold_color + cyan + '\n%s' % my_payload + bold_color + green
            elif data.startswith('SSH') == True and self.ssh_cmd == 1:
                self.ssh_cmd = 1
                if self.anti_sniff:
                    self.anti_sniffer()
                payload = self.replacer(self.payload + '[split]' + data)
                if self.locked:
                    my_payload = self.payloads
                else:
                    my_payload = [
                     self.replacer(self.payload)]
                print bold + bg + yellow + '[ Request ]' + default + bold_color + cyan + '\n%s' % my_payload + bold_color + green
                if '[split]' in payload or '[instant_split]' in payload:
                    payload = self.splitter(payload)
                else:
                    self.sock[self.s].send(payload)
            elif 'CONNECT' in data:
                self.ssh_cmd = 0
                if self.anti_sniff:
                    self.anti_sniffer()
                payload = self.replacer(self.payload)
                if self.locked:
                    my_payload = self.payloads
                else:
                    my_payload = [
                     self.replacer(self.payload)]
                print bold + bg + yellow + '[ Request ]' + default + bold_color + cyan + '\n%s' % my_payload + bold_color + green
                if '[split]' in payload or '[instant_split]' in payload:
                    payload = self.splitter(payload)
                else:
                    self.sock[self.s].send(payload)
        return


try:
    squid(lhost).loop()
except KeyboardInterrupt:
    print bold_color + red + '\nExit...' + bold_color + green
    exit()