# Deobfuscated by Uncompile
# Created by HTR-TECH (https://github.com/htr-tech)
# Instagram : @tahmid.rayat 

# uncompyle6 version 3.7.4
# Python bytecode 2.7
# Decompiled from: Python 2.7.13 (default, Aug 22 2020, 10:03:02) 
# [GCC 6.3.0 20170516]
# Embedded file name: script
from compile import *
import base64

class crypto:

    def file(self, f):
        f = f.replace('\x00\x00\x00\x00\x00\x00', '')
        decompiled = des().decrypt('!$#@(?;&', f, 1)
        key = decompiled[:8]
        f = decompiled[8:]
        decompiled = des().decrypt(key, f, 1)
        return decompiled