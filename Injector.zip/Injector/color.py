# Deobfuscated by Uncompile
# Created by HTR-TECH (https://github.com/htr-tech)
# Instagram : @tahmid.rayat 

# uncompyle6 version 3.7.4
# Python bytecode 2.7
# Decompiled from: Python 2.7.13 (default, Aug 22 2020, 10:03:02) 
# [GCC 6.3.0 20170516]
# Embedded file name: script
black = '30m'
red = '31m'
green = '32m'
brown = '33m'
blue = '34m'
magenta = '35m'
cyan = '36m'
lightgray = '37m'
purple = magenta
yellow = brown
white = lightgray
default = '\x1b[0m'
color = '\x1b[0;'
bold = '\x1b[1m'
bold_color = '\x1b[1;'
dark_color = '\x1b[2;'
underlines = '\x1b[4;'
bg = '\x1b[7;'
strikes_color = '\x1b[9;'
move_above = '\x1b[A'
move_under = '\x1b[B'
spacing_right = '\x1b[C'
spacing_left = '\x1b[D'
erase = '\x1b[2K'