# Deobfuscated by Uncompile
# Created by HTR-TECH (https://github.com/htr-tech)
# Instagram : @tahmid.rayat 

# uncompyle6 version 3.7.4
# Python bytecode 2.7
# Decompiled from: Python 2.7.13 (default, Aug 22 2020, 10:03:02) 
# [GCC 6.3.0 20170516]
# Embedded file name: script
from compile import *
import random, base64
letter = '\t\xff\rp\x90\x80\x12\x890\xaf\x0f'
key = ''
for x in range(0, 8):
    key += letter[random.randrange(0, len(letter))]

try:
    r = raw_input('nama file config: ')
except KeyboardInterrupt:
    exit()

if r:
    try:
        f = open(r).read()
    except IOError as e:
        print e
        exit()

    compiled = des().encrypt(key, f, 1)
    compiled = des().encrypt('!$#@(?;&', key + compiled, 1)
    c = '\x00\x00\x00\x00\x00\x00' + compiled
    c = base64.b64encode(c)
    hasil = r + '.si'
    try:
        compiled = open(hasil, 'w')
        compiled.write(c)
        compiled.close()
        print 'file config "%s" berhasil dikunci dengan nama "%s"' % (r, hasil)
    except Exception as e:
        print e
        exit()