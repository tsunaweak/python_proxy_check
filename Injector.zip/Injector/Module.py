# Deobfuscated by Uncompile
# Created by HTR-TECH (https://github.com/htr-tech)
# Instagram : @tahmid.rayat 

# uncompyle6 version 3.7.4
# Python bytecode 2.7
# Decompiled from: Python 2.7.13 (default, Aug 22 2020, 10:03:02) 
# [GCC 6.3.0 20170516]
# Embedded file name: script
import commands, os, sys

class execute:

    def comment(self, var):
        if var:
            print '_' * 42
            print 'Comments:', var
            print '_' * 42

    def shell(self, var):
        if var:
            r = raw_input('config file is containing shell commands:\n%s\nwant to execute it? [y/n] ' % var)
            if r.lower() == 'y':
                print '_' * 42
                print 'Output Shell:'
                print os.system(var)
                print '_' * 42

    def script(self, var):
        if var:
            r = raw_input('config file is containing script: \n%s\nwant to execute it? [y/n] ' % var)
            if r.lower() == 'y':
                print '_' * 42
                print 'Output Script:\n'
                try:
                    exec var
                except Exception as e:
                    print 'Script error:', e

                print '_' * 42