# Deobfuscated by Uncompile
# Created by HTR-TECH (https://github.com/htr-tech)
# Instagram : @tahmid.rayat 

# uncompyle6 version 3.7.4
# Python bytecode 2.7
# Decompiled from: Python 2.7.13 (default, Aug 22 2020, 10:03:02) 
# [GCC 6.3.0 20170516]
# Embedded file name: script
import os, select, time, random, commands, config_parser, module, sys, re
from socket import *
from color import *
os.system('clear')
t = 2
ts = 2
host = '216.58.201.163'

class pinger:

    def ping(self):
        s = socket(AF_INET, SOCK_STREAM)
        s.settimeout(5)
        try:
            ip = gethostbyname(host)
            s.connect((ip, 80))
            print bold + bg + green + 'PING!' + default + ' ==> ' + bold_color + green + host
            s.send('GET / HTTP/1.1\nHost: www.google.co.id\n\n')
            begin = time.time()
            res = s.recv(1024)
            if res:
                print bold_color + green + gethostname() + default + ' <== ' + bold + bg + green + 'PONG! ' + default + ' time:', time.time() - begin
                time.sleep(ts)
        except Exception as e:
            print bold + bg + green + 'PING' + default + ' ' + bold + bg + red + '' + default + bold_color + red + 'FAILED' + default + str(e) + bold_color + green
            s.close()
            print 'Retrying in %s seconds' % t
            time.sleep(t)


pinger().ping()