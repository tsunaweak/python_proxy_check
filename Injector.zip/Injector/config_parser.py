# Deobfuscated by Uncompile
# Created by HTR-TECH (https://github.com/htr-tech)
# Instagram : @tahmid.rayat 

# uncompyle6 version 3.7.4
# Python bytecode 2.7
# Decompiled from: Python 2.7.13 (default, Aug 22 2020, 10:03:02) 
# [GCC 6.3.0 20170516]
# Embedded file name: script


class parser:
    payloads = None
    remotes = None
    codes = '200 Connection established'
    lports = 9000
    comments = None
    shells = None
    scripts = None
    debugs = True
    confirms = 1
    pings = True
    ssh_user = None
    ssh_passwd = None
    replaces = False
    host = None
    port = None
    ssh_host = 'host'

    def conf(self, f):
        """if "<file>" in f and "</file>" in f:
        try:
          self.files=f.split("<file>")
          self.files=self.files[1].split("</file>")[0]
        except: self.files=None"""
        if '<payload>' in f and '</payload>' in f:
            try:
                self.payloads = f.split('<payload>')
                self.payloads = str(self.payloads[1]).split('</payload>')[0]
            except IndexError as e:
                print 'please check payload argument.\nError:', e

            if len(self.payloads) < 1 or self.payloads == ' ' * len(self.payloads):
                print 'payload is empty?'
                exit()
        else:
            print "Please insert your payload preferences (<payload>YOUR_PAYLOAD</payload>).\nCould't find <payload></payload> prefrences needed by this program.\nit's writed there?"
            exit()
        if '<remote>' in f and '</remote>' in f:
            try:
                self.remotes = f.split('<remote>')
                self.remotes = self.remotes[1].split('</remote>')[0]
                self.remotes = self.remotes.split(':')
                if len(self.remotes) > 2:
                    print 'Invalid remote given.\nMust be host:port'
                    exit()
                self.host = self.remotes[0]
                self.port = int(self.remotes[1])
            except Exception as e:
                print 'please check remote argument.\nmaybe caused by writing invalid port?'
                exit()

        else:
            print 'Please insert your remote preferences (<remote>host:port</remote>'
            exit()
        if '<code>' in f and '</code>' in f:
            try:
                self.codes = f.split('<code>')
                self.codes = self.codes[1].split('</code>')[0]
            except:
                self.codes = '200'

        if '<lport>' in f and '</lport>' in f:
            try:
                self.lports = f.split('<lport>')
                self.lports = int(self.lports[1].split('</lport>')[0])
            except:
                self.lports = 3128

        if '<comment>' in f and '</comment>' in f:
            try:
                self.comments = f.split('<comment>')
                self.comments = self.comments[1].split('</comment>')[0]
            except:
                pass

        if '<shell>' in f and '</shell>' in f:
            try:
                self.shells = f.split('<shell>')
                self.shells = self.shells[1].split('</shell>')[0]
            except:
                pass

        if '<script>' in f and '</script>' in f:
            try:
                self.scripts = f.split('<script>')
                self.scripts = self.scripts[1].split('</script>')[0]
            except:
                pass

        if '<debug>' in f and '</debug>' in f:
            try:
                self.debugs = f.split('<debug>')
                self.debugs = self.debugs[1].split('</debug>')[0]
            except:
                pass

        if '<confirm>' in f and '</confirm>' in f:
            try:
                self.confirms = f.split('<confirm>')
                self.confirms = self.confirms[1].split('</confirm>')[0]
            except:
                pass

        if '<ping>' in f and '</ping>' in f:
            try:
                self.pings = f.split('<ping>')
                self.pings = self.pings[1].split('</ping>')[0]
            except:
                pass

        if '<host>' in f and '</host>' in f:
            try:
                self.ssh_host = f.split('<host>')
                self.ssh_host = self.ssh_host[1].split('</host>')[0]
            except:
                pass

        if '<replace>' in f and '</replace>' in f:
            try:
                self.replaces = f.split('<replace>')
                self.replaces = self.replaces[1].split('</replace>')[0]
            except:
                pass

    def payload(self):
        return self.payloads

    def remote(self):
        return (
         self.host, self.port)

    def code(self):
        return self.codes

    def lport(self):
        return self.lports

    def comment(self):
        return self.comments

    def shell(self):
        return self.shells

    def script(self):
        return self.scripts

    def debug(self):
        return self.debugs

    def confirm(self):
        return self.confirms

    def is_ping(self):
        return self.pings

    def ssh(self):
        return self.ssh_host

    def replace(self):
        return self.replaces