
**NOTE:
Handphone harus sudah di ROOT!!!

akses root digunakan untuk meredirect paket dan mengikat (bind) port.

#*.Terlebih dahulu hp (handphone) harus terpasang python interpreter dan harus bisa menjalankan file py nya dari TE (karena author belum mencobanya via QPython/sl4a).
#*.Author memakai python 2.7 yang bisa dijalankan via Terminal


Langkah pertama..
Extract semua filenya kedalam satu folder.
Extract ke dalam folder: /sdcard/si/

Lanjut baca dibawah..

########################################
DAFTAR CODE XML UNTUK CONFIG SINJECTOR v2.4a

primary adalah code xml yang harus ada di dalam file config yang dibuat.
second adalah code xml yang tidak harus ada di dalam file config yang dibuat.

primary xml code:
<payload>PAYLOAD</payload> >>> untuk payloadnya
<remote>host:port</remote> >>> untuk remote servernya

second xml code:
<code>STATUS_CODE_RESPOND</code> >>> kirim status code ini ke client jika server tidak mengirim status code 200 (default: 200 Connection established)
<lport>local_port</lport> >>> untuk local port yang akan dipakai oleh sinjector (default: 9000)
<comment>COMMENT</comment> >>> untuk commentnya (misal: config dibuat oleh siapa)
<shell>shell code</shell> >>> masukkan script shell disini untuk di jalankan
<script>python script</script> >>> masukkan python script disini untuk dijalankan
<debug>0/1</debug> >>> untuk menampilkan/menyembunyikan debug (default: 1)
<ping>0/1</ping> >>> set ping on/off (default: 0)
<autoreplace>on/off</autoreplace> >>> set auto replace on/off (default: off)

untuk lebih jelasnya tentang cara membuat confignya, silakan cek file bernama config.cfg

author: RedFoX
sinjector v2.4a

sinjector is free to use without any warranty.
########################################

CARA MEMBUAT CONFIG:
buat file baru, misal bernama file.txt
lalu edit file.txt seperti ini:
<payload>GET / HTTP/1.1[crlf]Host: sakkarepmu\r\nConnection: Keep-Gretongan\r\nUser-Agent: sinjector_v2.4\r\n\r\n[raw][crlf*2]</payload> --> setelah edit payloadnya, maka harus ditutup dgn ini.
<remote>PROXY:PORT</remote>

PROXY misal: 10.8.3.8 atau 10.19.19.19 atau 10.4.0.10 dll
PORT misal 80 atau 8080 atau 8000 atau 3128 dll

setelah selesai.. save file.txt nya dan pindahkan file.txt nya kedalam folder yang sama dengan file-file yang sudah di extract sebelumnya (/sdcard/si/).

lanjut baca dibawah..

untuk mengunci confignya, jalankan file gen.py

setelah config selesai dibuat, lanjut baca dibawah.

lalu jalankan TE (Terminal) (kalau pakai Terminal Emulator), kalau pakai sl4a atau QPython juga bisa.. intinya jalankan script si.py nya dengan cara:
di terminal ketik:
cd /sdcard/si/  #berguna agar sinjector dapat membaca file module yang dibutuhkan dan juga agar dapat membaca file confignya.

jalankan file si.py nya:
python si.py [enter]
masukkan nama file confignya: file.txt (yang tadi telah dibuat sebelumnya).
sinjector akan membaca file confignya.
setelah sinjectornya selesai membuat server, lanjut buka ssh tunnel apk dan atur seperti ini:

langsung pergi ke ssh tunnel apk dan atur seperti ini:

dibagian Host ketik nama host sshnya
dibagian port ketik 443
dibagian user ketik nama pengguna akun sshnya
dibagian password ketik password akun sshnya
dibagian Use Sock Proxy dicentang 
local port bisa diubah atau biarkan saja
auto connect centang bila diperlukan
auto reconnect juga centang bila diperlukan
Enable GFW List biarkan saja jgn dicentang
Global Proxy centang (root)
Enable Upstream proxy dicentang
lalu isikan alamatnya: 127.0.0.1:9000
angka 9000 ganti dengan angka port yang ada diserver/yang tertampil diterminal
bila bingung, misal di terminal tampil: Mendengarkan 127.0.0.1:8000
nah, 8000 itu adalah portnya :)
untuk yg lainnya misal DNS dicentang juga tdk apa apa
ok langsung klik saja Tunnel Switch dan tunggu hingga terhubung...
kalo sudah terhubung berarti sudah berhasil digunakan :D

atau lewat Ki4a apk:
buka aplikasi Ki4a
klik icon pengaturan di pojok kanan atas
edit address dengan host ssh nya
edit port dengan port ssh nya (misal: 443)
edit username dengan nama pengguna ssh nya
edit password dengan password ssh nya
Enable HTTP Proxy aktifkan
isi address dengan 127.0.0.1
isi port dengan portnya (misal: 9000)
use iptables di aktifkan
yang lain biarkan kosong
lalu back dan klik icon tombol merah
tunggu hingga terhubung (nanti ada pemberitahuan: connected)

Payload Keyword:
[raw], [crlf], [lfcr], [host_port], [host], [port], [protocol], [ssh], [realData], [netData], [cr], [lf], [ua], [split], [crlf*N]

#Special payload keyword: [crlf*N] : ganti N dengan angka, misal: [crlf*2] maka nanti akan menjadi: \r\n\r\n atau [crlf][crlf]

#New Future Added: anti sniffer (experimental)
#Bug fixed:
#pinger

#Note:
belum support VPN (intinya vpn itu buat yg belum diroot).

Jika masih bingung dengan cara penggunaanya, silakan inbox author.

#cheers~

#FA2AS Facebook Group
#Author: RedFoX